package com.example.module;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ContactProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_profile);

        Button advanceToCreateBusinessContact = (Button) findViewById(R.id.returntocontactsButton);
        advanceToCreateBusinessContact.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent businessintent = new Intent(ContactProfile.this, Contacts.class);
                startActivity(businessintent);
            }
        });

    }

}


